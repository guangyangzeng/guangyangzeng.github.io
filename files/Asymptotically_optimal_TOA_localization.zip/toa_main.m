% TOA localization
% Copyright <2022>  <Guangyang Zeng, Biqiang Mu, Jiming Chen, Zhiguo Shi, Junfeng Wu>
% zengguangyang@cuhk.edu.cn, https://guangyangzeng.github.io/ 
% paper info. Global and Asymptotically Efficient Localization From Range Measurements, IEEE Transactions on Signal Processing, 70: 5041-5057, 2022.

clc
clear
result_BE=zeros(1,5);
result_NE=zeros(1,5);
result_BEL=zeros(1,5);
result_BE_GN=zeros(1,5);
result_NE_GN=zeros(1,5);
result_BEL_GN=zeros(1,5);
result_CRLB=zeros(1,5);
meas_num=zeros(1,5);
counter=1;
for t=0:0.5:2
T=round(10^t);
meas_num(counter)=10*T;
a=zeros(10,3);
aa=zeros(10*T,3);
true_position=zeros(1,3);
d=zeros(1,10*T);
error=0;
error_2=0;
error_3=0;
error_two_step=0;
error_two_step_2=0;
error_two_step_3=0;
error_SRLS=0;
Monte_carlo_number=10;  % Monte Carlo number
sigma=1;          
    true_position(1)=6;
    true_position(2)=6;
    true_position(3)=6;
    a(1,:)=[-5 -5 -5];
    a(2,:)=[-5 0 0];
    a(3,:)=[-5 5 -5];
    a(4,:)=[-5 -5 5];
    a(5,:)=[-5 0 -5];
    a(6,:)=[5 5 5];
    a(7,:)=[5 0 0];
    a(8,:)=[5 -5 5];
    a(9,:)=[5 5 -5];
    a(10,:)=[5 0 5];
for i=1:Monte_carlo_number   
    for j=1:10
        for k=1:T
            d(T*(j-1)+k)=norm(true_position-a(j,:))+randn*sigma;  
            aa(T*(j-1)+k,:)=a(j,:);
        end
    end
    [pos_BE,pos_BE_GN]=Bias_Eli_GN(aa,d',sigma);
    [pos_NE,~,pos_NE_GN]=Noise_Est_GN(aa,d');
    [pos_BEL,pos_BEL_GN]=Bias_Eli_Lin_GN(aa,d',sigma);
    
    error=error+norm(true_position'-pos_BE)^2;
    error_2=error_2+norm(true_position'-pos_NE)^2;
    error_3=error_3+norm(true_position'-pos_BEL)^2;
    error_two_step=error_two_step+norm(true_position'-pos_BE_GN)^2;
    error_two_step_2=error_two_step_2+norm(true_position'-pos_NE_GN)^2;
    error_two_step_3=error_two_step_3+norm(true_position'-pos_BEL_GN)^2;
end
result_BE(:,counter)=error/Monte_carlo_number;
result_NE(:,counter)=error_2/Monte_carlo_number;
result_BEL(:,counter)=error_3/Monte_carlo_number;
result_BE_GN(:,counter)=error_two_step/Monte_carlo_number;
result_NE_GN(:,counter)=error_two_step_2/Monte_carlo_number;
result_BEL_GN(:,counter)=error_two_step_3/Monte_carlo_number;
F=zeros(3,3);
for i=1:10*T
    F=F+(true_position'-aa(i,:)')*(true_position-aa(i,:))/norm(true_position-aa(i,:))^2;
end
F=F/sigma^2;
result_CRLB(:,counter)=trace(inv(F));
counter=counter+1;
end

loglog(meas_num,result_CRLB,'-k')
hold on
loglog(meas_num,result_BE,'-rs')
loglog(meas_num,result_BE_GN,'--rs')
loglog(meas_num,result_NE,'-b^')
loglog(meas_num,result_NE_GN,'--b^')
loglog(meas_num,result_BEL,'-g+')
loglog(meas_num,result_BEL_GN,'--g+')
xlabel('Measurement number')
ylabel('MSE')
legend('CRLB','BE','BE+GN','NE','NE+GN','BEL','BEL+GN')