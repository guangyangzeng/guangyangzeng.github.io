% TOA localization algorithm
% Input: a (m��n) is the coordinates (a 1��n vector) of m sensors
%        r (m��1) is the range measurements
%        sigma is the standard deviation of measurement noises
% Output: pos_est (n��1) is the Bias-Eli solution
%         pos_est_GN (n��1) is the refined solution by a one-step Gauss-Newton iteration

% Copyright <2022>  <Guangyang Zeng, Biqiang Mu, Jiming Chen, Zhiguo Shi, Junfeng Wu>
% zengguangyang@cuhk.edu.cn, https://guangyangzeng.github.io/ 
% paper info. Global and Asymptotically Efficient Localization From Range Measurements, IEEE Transactions on Signal Processing, 70: 5041-5057, 2022.

function [pos_est,pos_est_GN]=Bias_Eli_GN(a,r,sigma) 
%% Initialization
m=size(a,1);  
n=size(a,2);  
b=zeros(m,1);
A=zeros(m,n+1);
D=diag([ones(1,n) 0]);
f=[zeros(n,1);-0.5];
for i=1:m
    b(i)=r(i)^2-norm(a(i,:))^2-sigma^2;
    A(i,:)=[-2*a(i,:) 1];
end
%% First step
cvx_begin sdp quiet;
variable lambda;
minimize(lambda);
A'*A+lambda*D>=0;
cvx_end;

lambda_l=lambda+2;
y_l=(A'*A+lambda_l*D)\(A'*b-lambda_l*f);
while (y_l'*D*y_l+2*f'*y_l)<0
    lambda_l=(lambda+lambda_l)/2;
    y_l=(A'*A+lambda_l*D)\(A'*b-lambda_l*f);
end

lambda_u=lambda+2;
y_u=(A'*A+lambda_u*D)\(A'*b-lambda_u*f);
while (y_u'*D*y_u+2*f'*y_u)>0
    lambda_u=lambda_u+(lambda_u-lambda)*2;
    y_u=(A'*A+lambda_u*D)\(A'*b-lambda_u*f);
end

while (lambda_u-lambda_l)>0.00001
    lambda_temp=(lambda_u+lambda_l)/2;
    y_temp=(A'*A+lambda_temp*D)\(A'*b-lambda_temp*f);
    if (y_temp'*D*y_temp+2*f'*y_temp)>0
        lambda_l=lambda_temp;
    else
        lambda_u=lambda_temp;
    end
end

y=(A'*A+lambda_u*D)\(A'*b-lambda_u*f);
pos_est=y(1:n);

%% A one-step Gauss-Newton iteration
 v=zeros(m,1);
 J=zeros(m,n);
 for k=1:m
     v(k)=norm(pos_est-a(k,:)');
     J(k,:)=(pos_est-a(k,:)')'/norm(pos_est-a(k,:)');
 end
 pos_est_GN=pos_est+(J'*J)\J'*(r-v);