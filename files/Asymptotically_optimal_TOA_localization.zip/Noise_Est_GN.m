% TOA localization algorithm
% Input: a (m×n) is the coordinates (a 1×n vector) of m sensors
%        r (m×1) is the range measurements
% Output: pos_est (n×1) is the Bias-Eli solution
%         pos_est_GN (n×1) is the refined solution by a one-step Gauss-Newton iteration
%         var_est is the estimated variance of measurement noises

% Copyright <2022>  <Guangyang Zeng, Biqiang Mu, Jiming Chen, Zhiguo Shi, Junfeng Wu>
% zengguangyang@cuhk.edu.cn, https://guangyangzeng.github.io/ 
% paper info. Global and Asymptotically Efficient Localization From Range Measurements, IEEE Transactions on Signal Processing, 70: 5041-5057, 2022.

function [pos_est,var_est,pos_est_GN]=Noise_Est_GN(a,r) 
%% First step
m=size(a,1);  
n=size(a,2);  
b=zeros(m,1);
A=zeros(m,n+1);
for i=1:m
    b(i)=r(i)^2-norm(a(i,:))^2;
    A(i,:)=[-2*a(i,:) 1];
end
D=diag([ones(1,n) 0]);
f=[zeros(1,n) -0.5]';

cvx_begin sdp quiet;
variable y(n+1);
minimize(norm(A*y-b,2));
y'*D*y+2*f'*y<=0;
cvx_end;
pos_est=y(1:n);
var_est=y(n+1)-norm(pos_est)^2;

%% A one-step Gauss-Newton iteration
 v=zeros(m,1);
 J=zeros(m,n);
 for k=1:m
     v(k)=norm(pos_est-a(k,:)');
     J(k,:)=(pos_est-a(k,:)')'/norm(pos_est-a(k,:)');
 end
 pos_est_GN=pos_est+(J'*J)\J'*(r-v);
