% TDOA localization algorithm
% Input: a (n��m) is the coordinates of n sensors which does not include the
% reference sensor; the coordinates of the reference sensor is assumed to
% be 0.
%        d (n��1) is the range-difference measurements.
% Output: target_position (m��1) is the estimate of the target's coordinates
%         exitflag indicates the subset in which the optimal Lagrange
%         multiplier locates

% Copyright <2022>  <Guangyang Zeng, Biqiang Mu, Jieqiang Wei, Wing Shing Wong, Junfeng Wu>
% zengguangyang@cuhk.edu.cn, https://guangyangzeng.github.io/ 
% paper info. Localizability with Range-Difference Measurements: Numerical Computation and Error Bound Analysis, IEEE/ACM Transactions on Networking, 30(5): 2117-2130, 2022.

function [target_position,exitflag]=CLSsolver(a,d) 
%% initilization
n=length(d);
m=size(a,2);
b=zeros(n,1);
A=zeros(n,m+1);
D=diag([1 -ones(1,m)]);
for i=1:n
    b(i)=((norm(a(i,:)))^2-d(i)^2)/2;
    A(i,:)=[d(i) a(i,:)];
end
%% algorithm starts
y=zeros(m+1,0);
if norm(b)<0.001
    target_position=y(2:m+1);
    exitflag=0;
    return
else
    
%     cvx_begin sdp quiet;
%     variable lamuda_u;
%     maximize(lamuda_u);
%     A'*A+lamuda_u*D>=0;
%     cvx_end;
%     cvx_begin sdp quiet;
%     variable lamuda_l;
%     minimize(lamuda_l);
%     A'*A+lamuda_l*D>=0;
%     cvx_end;

    eig_lambda=eig(D,A'*A);
    lamuda_l=-1/max(eig_lambda);
    lamuda_u=-1/min(eig_lambda);

    
    %searching in the positive-definite interval
    y_l=(A'*A+(lamuda_l+0.001)*D)\A'*b;  
    h_l=y_l'*D*y_l;
    y_u=(A'*A+(lamuda_u-0.001)*D)\A'*b;  
    h_u=y_u'*D*y_u;
    if (h_l>0)&&(h_u<0)
       while ((lamuda_u-lamuda_l)>0.000001)  
           lamuda_m=(lamuda_u+lamuda_l)/2;
           y_m=(A'*A+lamuda_m*D)\A'*b;
           h_m=y_m'*D*y_m;
           if h_m<0
               lamuda_u=lamuda_m;
           else
               lamuda_l=lamuda_m;
           end
       end
       lamuda_optimal=(lamuda_u+lamuda_l)/2;
       y_optimal=(A'*A+lamuda_optimal*D)\A'*b;
       if y_optimal(1)>0
           y=y_optimal;
           target_position=y(2:m+1);
           exitflag=1;
           return
       end
       
       %searching on the singular points
    elseif (h_l<0)&&(h_u<0)
        y_star=(A'*A+(lamuda_l+0.001)*D)\A'*b;  
        O=A'*A+lamuda_l*D;
        [tezhengxl,~]=eig(O);
        TEMP=norm(O*tezhengxl(:,1));
        INDEX=1;
        for k=2:m+1
            if norm(O*tezhengxl(:,k))<TEMP
                TEMP=norm(O*tezhengxl(:,k));
                INDEX=k;
            end
        end
        z_negative=tezhengxl(:,INDEX);
        z_negative=z_negative/norm(z_negative);
        aaa=z_negative'*D*z_negative;
        bbb=2*y_star'*D*z_negative;
        ccc=y_star'*D*y_star;
        alfa1=(-bbb+(bbb^2-4*aaa*ccc)^0.5)/(2*aaa);
        alfa2=(-bbb-(bbb^2-4*aaa*ccc)^0.5)/(2*aaa);
        y_G_star1=y_star+alfa1*z_negative;
        y_G_star2=y_star+alfa2*z_negative;
        if y_G_star1(1)>0
            target_position=y_G_star1(2:m+1);
            exitflag=2;
            return
        else
            target_position=y_G_star2(2:m+1);
            exitflag=2;
            return
        end
    elseif (h_l>0)&&(h_u>0)
        temp=(A'*A)\A'*b;
        if temp(1)>0
            save temp temp
            y_star=(A'*A+(lamuda_u-0.001)*D)\A'*b;
        O=A'*A+lamuda_u*D;
        [tezhengxl,~]=eig(O);
        TEMP=norm(O*tezhengxl(:,1));
        INDEX=1;
        for k=2:m+1
            if norm(O*tezhengxl(:,k))<TEMP
                TEMP=norm(O*tezhengxl(:,k));
                INDEX=k;
            end
        end
        z_positive=tezhengxl(:,INDEX);
            z_positive=z_positive/norm(z_positive);
            aaa=z_positive'*D*z_positive;
            bbb=2*y_star'*D*z_positive;
            ccc=y_star'*D*y_star;
            alfa1=(-bbb+(bbb^2-4*aaa*ccc)^0.5)/(2*aaa);
            y_G_star=y_star+alfa1*z_positive;
            target_position=y_G_star(2:m+1);
            exitflag=3;
            return
        end
    end
    
    %searching in the indefinite interval
    [Q,LAMUDA]=eig(A'*A);
    R=Q*LAMUDA^(-0.5);
    [V,SIGAMA]=eig(R'*D*R);
    P=R*V;
    F=P'*A'*b;
    if m==3
    coeff=F(1)^2*SIGAMA(1,1)*conv(conv([SIGAMA(2,2)^2 2*SIGAMA(2,2) 1],[SIGAMA(3,3)^2 2*SIGAMA(3,3) 1]),[SIGAMA(4,4)^2 2*SIGAMA(4,4) 1])+...
        F(2)^2*SIGAMA(2,2)*conv(conv([SIGAMA(1,1)^2 2*SIGAMA(1,1) 1],[SIGAMA(3,3)^2 2*SIGAMA(3,3) 1]),[SIGAMA(4,4)^2 2*SIGAMA(4,4) 1])+...
        F(3)^2*SIGAMA(3,3)*conv(conv([SIGAMA(1,1)^2 2*SIGAMA(1,1) 1],[SIGAMA(2,2)^2 2*SIGAMA(2,2) 1]),[SIGAMA(4,4)^2 2*SIGAMA(4,4) 1])+...
        F(4)^2*SIGAMA(4,4)*conv(conv([SIGAMA(1,1)^2 2*SIGAMA(1,1) 1],[SIGAMA(2,2)^2 2*SIGAMA(2,2) 1]),[SIGAMA(3,3)^2 2*SIGAMA(3,3) 1]);
    else
    coeff=F(1)^2*SIGAMA(1,1)*conv([SIGAMA(2,2)^2 2*SIGAMA(2,2) 1],[SIGAMA(3,3)^2 2*SIGAMA(3,3) 1])+...
        F(2)^2*SIGAMA(2,2)*conv([SIGAMA(1,1)^2 2*SIGAMA(1,1) 1],[SIGAMA(3,3)^2 2*SIGAMA(3,3) 1])+...
        F(3)^2*SIGAMA(3,3)*conv([SIGAMA(1,1)^2 2*SIGAMA(1,1) 1],[SIGAMA(2,2)^2 2*SIGAMA(2,2) 1]);
    end
    ROOTS=roots(coeff);
    for i=1:length(ROOTS)
        if isreal(ROOTS(i))&&(ROOTS(i)<lamuda_l)
            y_star=(A'*A+ROOTS(i)*D)\A'*b;
            if y_star(1)>0
                target_position=y_star(2:m+1);
                exitflag=4;
                return
            end 
        end
    end
           target_position=zeros(m,1);
           exitflag=5; 
           return
end