% TDOA localization algorithm
% Input: a (n��m) is the coordinates (a 1��m vector) of n sensors, not
%        including the reference sensor. The reference sensor is fixed at 0. 
%        d (n��1) is the range measurements
% Output: pos_est (m��1) is the initial solution
%         pos_est_GN (m��1) is the refined solution by a one-step Gauss-Newton iteration
%         var_est is the estimated variance of measurement noises

% Written with Matlab version R2022a

% Copyright <2023>  <Guangyang Zeng, Biqiang Mu, Ling Shi, Jiming Chen, Junfeng Wu>
% zengguangyang@cuhk.edu.cn, https://guangyangzeng.github.io/ 
% paper info. Consistent and Asymptotically Efficient Localization from Range-Difference Measurements, 
%             IEEE Transactions on Information Theory, 2023, DOI: 10.1109/TIT.2023.3343347.

function [pos_est,pos_est_GN,var_est]=linear_tdoa_NE_GN(a,d)
%% noise variance estimation
possible_sig=[];
[n,m]=size(a);
A=zeros(n,m+3);
for i=1:n
    A(i,:)=[-2*a(i,:) 1 -2*d(i) d(i)^2-norm(a(i,:))^2];
end
d_bar=sum(d)/n;
d2_bar=sum(d.^2)/n;
R=(A'*A)/n;
R_used=R(m+2:m+3,m+2:m+3)-R(m+2:m+3,1:m+1)/R(1:m+1,1:m+1)*R(1:m+1,m+2:m+3);
c1=R_used(1,1)*R_used(2,2)-R_used(1,2)^2;
c2=4*R_used(1,1)*d2_bar+4*R_used(2,2)+8*R_used(1,2)*d_bar;
c3=16*d2_bar-16*d_bar^2;
p=[32 -8*R_used(1,1)-4*c3 4*c2 -4*c1];
Rootss=roots(p);
l=length(Rootss);
for i=1:l
    if (2*c1+2*R_used(1,1)*Rootss(i)^2-c2*Rootss(i))>0
        possible_sig=[possible_sig;Rootss(i)];
    end
end
var_est=min(possible_sig);


%% bias-eliminated solution
b=zeros(n,1);
A=zeros(n,m+1);
for i=1:n
    b(i)=d(i)^2-(norm(a(i,:)))^2-var_est;
    A(i,:)=[-2*a(i,:) -2*d(i)];
end
G=[zeros(n,m) -2*ones(n,1)];
y_ls=((A'*A-var_est*(G'*G))/n)\((A'*b-2*var_est*G'*d)/n);
pos_est=y_ls(1:m);

%% GN refinement
v=zeros(n,1);
    J=zeros(n,3);
    for k=1:n
        v(k)=norm(pos_est-a(k,:)')-norm(pos_est);
        J(k,:)=(pos_est-a(k,:)')'/norm(pos_est-a(k,:)')-pos_est'/norm(pos_est);
    end
    pos_est_GN=pos_est+(J'*J)\J'*(d-v);